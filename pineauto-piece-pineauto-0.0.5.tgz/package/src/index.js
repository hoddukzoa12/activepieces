"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.pineauto = exports.pineautoauth = void 0;
const tslib_1 = require("tslib");
const pieces_framework_1 = require("@activepieces/pieces-framework");
const bs58_1 = tslib_1.__importDefault(require("bs58"));
const signer_1 = require("./lib/common/signer");
const create_order_1 = require("./lib/actions/create-order");
const tradingviewwebhook_1 = require("./lib/triggers/tradingviewwebhook");
exports.pineautoauth = pieces_framework_1.PieceAuth.CustomAuth({
    description: 'PineAuto 의 api key 를 입력하세요.',
    props: {
        environment: pieces_framework_1.Property.StaticDropdown({
            displayName: 'Environment',
            description: 'Select Orderly Network environment',
            required: true,
            defaultValue: 'testnet',
            options: {
                options: [
                    { label: 'Mainnet', value: 'mainnet' },
                    { label: 'Testnet', value: 'testnet' },
                ]
            }
        }),
        account_id: pieces_framework_1.Property.ShortText({
            displayName: 'Account ID',
            description: 'Your Orderly account ID (e.g., 0x1234...)',
            required: true,
        }),
        public_key: pieces_framework_1.PieceAuth.SecretText({
            displayName: 'Public Key',
            description: 'Your Orderly public key',
            required: true
        }),
        secret_key: pieces_framework_1.PieceAuth.SecretText({
            displayName: 'Secret Key',
            description: 'Your Orderly secret key (Base58 encoded)',
            required: true
        })
    },
    validate: (_a) => tslib_1.__awaiter(void 0, [_a], void 0, function* ({ auth }) {
        try {
            const typedAuth = auth;
            // Base58 디코딩
            const privateKey = bs58_1.default.decode(typedAuth.secret_key);
            // API 엔드포인트 결정
            const baseUrl = typedAuth.environment === 'mainnet'
                ? 'https://api.orderly.org'
                : 'https://testnet-api.orderly.org';
            // 계정 정보 확인으로 검증
            const response = yield (0, signer_1.signAndSendRequest)(typedAuth.account_id, privateKey, `${baseUrl}/v1/client/info`, { method: 'GET' });
            if (response.ok) {
                return { valid: true };
            }
            else {
                const error = yield response.text();
                return {
                    valid: false,
                    error: `Authentication failed: ${error}`
                };
            }
        }
        catch (error) {
            return {
                valid: false,
                error: `Invalid credentials: ${error}`
            };
        }
    }),
    required: true
});
exports.pineauto = (0, pieces_framework_1.createPiece)({
    displayName: "Pineauto",
    auth: exports.pineautoauth,
    minimumSupportedRelease: '0.36.1',
    logoUrl: "https://logo.pineauto.app/Pavicon.png",
    authors: ["hoddukzoa"],
    actions: [create_order_1.createOrder],
    triggers: [tradingviewwebhook_1.tradingviewwebhook],
});
//# sourceMappingURL=index.js.map