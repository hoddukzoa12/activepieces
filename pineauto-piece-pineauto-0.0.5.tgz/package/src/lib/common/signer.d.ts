export declare function signAndSendRequest(orderlyAccountId: string, privateKey: Uint8Array | string, input: URL | string, init?: RequestInit | undefined): Promise<Response>;
