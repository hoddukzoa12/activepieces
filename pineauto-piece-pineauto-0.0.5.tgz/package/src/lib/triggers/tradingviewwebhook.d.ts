import { TriggerStrategy } from '@activepieces/pieces-framework';
export interface TradingViewOrderEvent {
    symbol: string;
    leverage: number;
    side: 'buy' | 'sell';
    qtyMode: 'percent' | 'fixed';
    qty: number;
    clientOrderId?: string;
    rawPayload: unknown;
    emittedAt: number;
}
export declare const tradingviewwebhook: import("@activepieces/pieces-framework").ITrigger<TriggerStrategy.WEBHOOK, import("@activepieces/pieces-framework").PieceAuthProperty, {
    help_text: import("dist/packages/pieces/community/framework/src/lib/property/input/markdown-property").MarkDownProperty;
    live_url: import("dist/packages/pieces/community/framework/src/lib/property/input/markdown-property").MarkDownProperty;
    webhook_secret: import("@activepieces/pieces-framework").ShortTextProperty<true>;
    default_symbol: import("@activepieces/pieces-framework").ShortTextProperty<true>;
    leverage: import("@activepieces/pieces-framework").NumberProperty<true>;
}> | import("@activepieces/pieces-framework").ITrigger<TriggerStrategy.POLLING, import("@activepieces/pieces-framework").PieceAuthProperty, {
    help_text: import("dist/packages/pieces/community/framework/src/lib/property/input/markdown-property").MarkDownProperty;
    live_url: import("dist/packages/pieces/community/framework/src/lib/property/input/markdown-property").MarkDownProperty;
    webhook_secret: import("@activepieces/pieces-framework").ShortTextProperty<true>;
    default_symbol: import("@activepieces/pieces-framework").ShortTextProperty<true>;
    leverage: import("@activepieces/pieces-framework").NumberProperty<true>;
}> | import("@activepieces/pieces-framework").ITrigger<TriggerStrategy.APP_WEBHOOK, import("@activepieces/pieces-framework").PieceAuthProperty, {
    help_text: import("dist/packages/pieces/community/framework/src/lib/property/input/markdown-property").MarkDownProperty;
    live_url: import("dist/packages/pieces/community/framework/src/lib/property/input/markdown-property").MarkDownProperty;
    webhook_secret: import("@activepieces/pieces-framework").ShortTextProperty<true>;
    default_symbol: import("@activepieces/pieces-framework").ShortTextProperty<true>;
    leverage: import("@activepieces/pieces-framework").NumberProperty<true>;
}>;
