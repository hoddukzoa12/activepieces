export declare const createOrder: import("@activepieces/pieces-framework").IAction<import("@activepieces/pieces-framework").PieceAuthProperty, {
    order_event: import("@activepieces/pieces-framework").JsonProperty<true>;
    reduce_only: import("@activepieces/pieces-framework").CheckboxProperty<false>;
    client_order_id: import("@activepieces/pieces-framework").ShortTextProperty<false>;
}>;
