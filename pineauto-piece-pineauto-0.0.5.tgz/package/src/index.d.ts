export type PineautoAuthType = {
    environment: 'mainnet' | 'testnet';
    account_id: string;
    public_key: string;
    secret_key: string;
};
export declare const pineautoauth: import("@activepieces/pieces-framework").CustomAuthProperty<{
    environment: import("@activepieces/pieces-framework").StaticDropdownProperty<string, true>;
    account_id: import("@activepieces/pieces-framework").ShortTextProperty<true>;
    public_key: import("@activepieces/pieces-framework").SecretTextProperty<true>;
    secret_key: import("@activepieces/pieces-framework").SecretTextProperty<true>;
}>;
export declare const pineauto: import("@activepieces/pieces-framework").Piece<import("@activepieces/pieces-framework").PieceAuthProperty>;
